#include <stdio.h>

typedef int T;
#include "SortedList.h"

TSortedList getNaturals(int A, int B)
{
    TSortedList nats = NULL;
    int i;
    for (i = A; i <= B; i++)
    {
        nats = insert(nats, i);
    }
    return nats;
}

int prim(int n)
{
    int ok = 1;
    if (n < 2)
        ok = 0;
    else
    {
        for (int i = 2; i <= n / 2; i++)
        {
            if (n % i == 0)
            {
                ok = 0;
                break;
            }
        }
    }
    return ok;
}

TSortedList getPrimes(int N)
{
    TSortedList nats = getNaturals(2, N);
    TSortedList list = nats;
    TSortedList lista_aux1;
    TSortedList lista_aux2 = nats;
    // TODO: Cerința Bonus
    while (list != NULL)
    {
        if (prim(list->value) == 1)
        {
            list = list->next;
            lista_aux1 = list;
            while (lista_aux1 != NULL)
            {
                if (lista_aux1->value % list->value == 0)
                {
                    lista_aux2 = deleteOnce(nats, lista_aux1->value);
                    lista_aux1 = lista_aux1->next;
                }
                lista_aux1 = lista_aux1->next;
            }
            list = lista_aux2;
        }
        else
            list = list->next;
    }
    return list;
}

void printInts(TSortedList list)
{
    while (!isEmpty(list))
    {
        printf("%d ", list->value);
        list = list->next;
    }
    printf("\n");
}

int main(int argc, char *argv[])
{
    printInts(getPrimes(100));
    return 0;
}
